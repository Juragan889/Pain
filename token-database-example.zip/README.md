# Token Database Example

Database token sederhana untuk API/bot dalam format JSON.

## Cara Pakai:
- Tambahkan token baru di file `tokens.json`
- Akses file ini secara online via:
  https://raw.githubusercontent.com/username/token-database-example/main/tokens.json
